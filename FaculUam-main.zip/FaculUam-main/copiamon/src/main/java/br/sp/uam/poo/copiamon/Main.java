
package br.sp.uam.poo.copiamon;

import java.util.Scanner;

public class Main {

   
    public static void main(String[] args) {
        
    	Scanner sc = new Scanner(System.in);
    	
        System.out.println("Batalha pokemon ");
        System.out.println("----------------");
        System.out.println("1 - Isqueirinho ");
        System.out.println("tipo: Fogo");
        System.out.println("Poder: 10");
        System.out.println("Defesa: 15 \n");
        System.out.println("2 - Geloso ");
        System.out.println("tipo: Gelo");
        System.out.println("Poder: 8");
        System.out.println("Defesa: 20 \n");
        System.out.println("");
        System.out.println("3 - Taser");
        System.out.println("tipo: Eletrico");
        System.out.println("Poder: 5");
        System.out.println("Defesa: 11 \n");
        System.out.println("");
        System.out.println("4 - Bufoso");
        System.out.println("tipo: Gasoso");
        System.out.println("Poder: 6");
        System.out.println("Defesa: 7 \n");
        System.out.println("");
        System.out.println("5 - Areioso");
        System.out.println("tipo: Areia");
        System.out.println("Poder: 8");
        System.out.println("Defesa: 13 \n");
        System.out.println("");
        System.out.println("6 -  Ervinha");
        System.out.println("tipo: Planta");
        System.out.println("Poder: 6");
        System.out.println("Defesa: 12 \n");
        System.out.println("----------------");
        System.out.println("Selecione o numero do pokemon que deseja: ");
        int num = sc.nextInt();
        
        switch(num) {
        case 1:
        	Atributos Isqueirinho = new Atributos("Baforada-Quente", "Plasma", 3, "Isqueirinho", "Fogo", 10, 10, 15, 3); 
        	System.out.println("O monstro selecionado foi " + Isqueirinho.getNome());
        	break;
        case 2:
        	Atributos Geloso = new Atributos("Ataque-neutro", "Neutro", 2, "Geloso", "Gelo", 16, 8, 20, 1);
        	System.out.println("O monstro selecionado foi " + Geloso.getNome());
        	break;
        case 3:
        	Atributos Taser = new Atributos("1000V", "Choque", 3, "Taser", "Eletrico", 8, 5, 11, 1);  
        	System.out.println("O monstro selecionado foi " + Taser.getNome());        	
        	break;
        case 4:
        	Atributos Bufoso = new Atributos("Bufa", "Gasoso", 3, "Bufoso", "Gas", 13, 6, 7, 2);  
        	System.out.println("O monstro selecionado foi " + Bufoso.getNome());
        	break;
        case 5:
        	Atributos Areioso = new Atributos("Tempestade de Areia", "Grao", 2, "Areioso", "Areia", 8, 8, 13, 2);  
        	System.out.println("O monstro selecionado foi " + Areioso.getNome());
        	break;
        case 6:
        	Atributos Ervinha = new Atributos("Cipo Milenar", "Plantoso", 1, "Ervinha", "Planta", 12, 6, 12, 3);  
        	System.out.println("O monstro selecionado foi " + Ervinha.getNome());
        	break;
        }
        
        
    }
    
}
